# authtoken.py
#Have refreshed token need to review how to keep it safe

# How to get one: https://huggingface.co/docs/hub/security-tokens

auth_token = "{hf_ paste over this with the top secret code jIaogmcNTdvjBZtEzwoquwCqnR)}"

#See teams chat
